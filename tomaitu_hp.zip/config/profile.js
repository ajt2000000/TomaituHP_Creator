document.addEventListener("DOMContentLoaded", function() {
    const siteTitle = "とまいつTVのホームページ[仮]";
    document.title = siteTitle;

    const headerImageUrl = "config/image/i1.webp"; // Link to the header image
    const mainImageUrl = "config/image/t1.webp"; // Link to the main image

    document.getElementById("header-img").src = headerImageUrl;
    document.getElementById("main-img").src = mainImageUrl;

    const profileData = `
        <table id="profile">
            <tbody>
                <tr><th>チャンネル名</th><td>とまいつTV</td></tr>
                <tr><th>バンドル名</th><td>@tometoo123</td></tr>
                <tr><th>チャンネルID</th><td>UCK-QIv5UUXWYi2W7s_F4rCQ</td></tr>
                <tr><th>チャンネル作成日</th><td>2012/09/28</td></tr>
                <tr><th>再生回数</th><td>2,382 回</td></tr>
                <tr><th>最終動画投稿日</th><td>2024/06/14</td></tr>
                <tr><th>チャンネル登録者数</th><td>403人</td></tr>
                <tr><th>動画数</th><td>3本の動画</td></tr>
                <tr><th>Noxスコア</th><td>☆☆☆☆☆ 0点</td></tr>
                <tr><th>収益化</th><td>非公開</td></tr>
                <tr><th>リンク</th><td><a href="https://x.gd/OJZ30">YouTube</a><a href="https://x.gd/Och5H"> TikTok</a></td></tr>
            </tbody>
        </table>
    `;

    const newsData = `
        <table id="news">
            <tbody>
                <tr><th>2024/07/25</th><td>失踪かも～～</td></tr>
                <tr><th>2023/01/25</th><td>とまいつTVが<a href="https://x.gd/hcgr1K">とまとぉ</a>と言うアカウントを開設</td></tr>
            </tbody>
        </table>
    `;

    document.getElementById("profile-container").innerHTML = profileData;
    document.getElementById("news-container").innerHTML = newsData;
});
